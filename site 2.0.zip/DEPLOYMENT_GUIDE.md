# MLT Esports Platform - Deployment Guide

## Files Created/Updated

### New Pages (from Задание.txt requirements):
- ✅ `match-details.html` - Match details with player stats per map
- ✅ `player-profile.html` - Player profile with form graph and achievements
- ✅ `team-profile.html` - Team profile with lineup and map statistics

### Updated Files:
- ✅ `assets/js/main.js` - Navigation links to new profile pages
- ✅ `firebase.json` - Fixed deployment configuration
- ✅ All HTML files - Added logo and favicon

### Helper Files:
- ✅ `deploy-setup.sh` - Script to copy files to public/ folder
- ✅ `populate-firestore.html` - Script to populate Firestore with sample data

## Deployment Instructions

### Option 1: Using Cloud Shell

1. **Upload files to Cloud Shell:**
   - Upload ALL files from `d:\Заказ\MLT\site\` to Cloud Shell
   - Make sure to upload: `deploy-setup.sh` and `populate-firestore.html`

2. **Run setup script in Cloud Shell:**
   ```bash
   chmod +x deploy-setup.sh
   ./deploy-setup.sh
   ```

3. **Deploy to Firebase:**
   ```bash
   firebase deploy --only hosting
   ```

### Option 2: Manual Setup

1. **Create public folder structure:**
   ```bash
   mkdir -p public/assets/css
   mkdir -p public/assets/js
   ```

2. **Copy files manually:**
   - Copy all HTML files to `public/`
   - Copy `firebase.json`, `.firebaserc`, `config.js`, `firestore.rules`, `logo.jpg` to `public/`
   - Copy `assets/css/style.css` to `public/assets/css/`
   - Copy `assets/js/firebase-config.js` and `assets/js/main.js` to `public/assets/js/`

3. **Deploy:**
   ```bash
   firebase deploy --only hosting
   ```

## Populating Firestore with Sample Data

1. **Open `populate-firestore.html` in your browser:**
   - This file connects to your Firebase project
   - Click "Populate Data" to add sample teams, players, matches, tournaments, and news
   - Click "Clear All Data" to remove all data

2. **Sample data includes:**
   - 3 teams (Team Alpha, Team Beta, Team Gamma)
   - 10 players with realistic stats
   - 1 tournament with bracket structure
   - 3 matches (live, upcoming, finished)
   - 3 news articles

## Verification Steps

After deployment:

1. **Check main site:** https://mlt-site.web.app/
   - Should show logo in header
   - Should display sample data (matches, rankings, news)

2. **Test navigation:**
   - Click on matches → should open match-details.html
   - Click on teams in rankings → should open team-profile.html
   - Click on players in rankings → should open player-profile.html

3. **Test authentication:**
   - Click "Войти" button → should open auth modal
   - Try registering a new account
   - First registered user becomes admin automatically

4. **Test admin panel:**
   - Access /admin.html
   - Should see admin controls if logged in as admin

## Current Status

✅ All required pages from Задание.txt implemented
✅ Firebase deployment configuration fixed
✅ Logo added to all pages
✅ Navigation between profile pages working
✅ Sample data population script ready
⏳ Deployment pending (needs Cloud Shell execution)
⏳ Final testing pending (after deployment)

## Next Steps

1. Deploy using the instructions above
2. Populate Firestore with sample data
3. Test all functionality
4. Verify user flow (registration → tournament signup → admin approval)
